    <!-- Why choose  -->
    <?php foreach($about_us as $row){

        echo $row->description;
    }

   ?>
    <!-- Why choose  -->
        <!-- Ends How-it-works -->
      <?php $this->load->view('lesson_count.php'); ?>
