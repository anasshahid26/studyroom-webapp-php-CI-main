 <!-- Counter -->
        <div class="home-counting">
            <div class="container">
                <div class="row row-margin">
                    <div class="col-md-12">
                        <h2 class="counter-block"><?php echo get_languageword('There are'); ?> <span id=""><?php echo get_lessons_taught_cnt(); ?></span> <?php echo get_languageword('lessons taught already'); ?>!</h2>
                    </div>
                </div>
            </div>
        </div>
        <!-- Counter -->